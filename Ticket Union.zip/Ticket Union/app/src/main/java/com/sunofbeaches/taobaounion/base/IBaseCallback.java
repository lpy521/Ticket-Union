package com.sunofbeaches.taobaounion.base;

public interface IBaseCallback {

    void onError();

    void onLoading();

    void onEmpty();
}
