package com.lcodecore.tkrefreshlayout;

/**
 * Created by lcodecore on 2016/11/26.
 */

public interface OnAnimEndListener {

    public void onAnimEnd();
}
